// 1. Write a custom function power(a, b), to calculate the value of a raised to b.

function power(a, b) {
  var power = a ** b;
  return power;
}

document.write("<h1>" + power(2, 3) + "</h1>");
