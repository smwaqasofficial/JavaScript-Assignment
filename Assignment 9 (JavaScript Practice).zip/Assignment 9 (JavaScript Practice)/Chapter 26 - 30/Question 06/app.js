// 6. Write a program that shows a random number between 1 and 100 in your browser.

var randNum = Math.floor(Math.random() * 100 + 1);

document.write("<h1>random number between 1 and 100: " + randNum + "</h1>");
