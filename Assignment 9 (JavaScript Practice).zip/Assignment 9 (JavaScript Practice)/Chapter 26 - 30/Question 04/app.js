// 4. Write a program that simulates a dice using random() method of JS Math class.
// Display the value of dice in your browser.

var randDice = Math.floor(Math.random() * 6 + 1);

document.write("<h1>Random dice value: " + randDice + "</h1>");
