// 3. Write a program that displays the absolute value of a number.E.g.absolute value of - 4 is 4 & absolute value of 5 is 5

var num = -4;

var absVal = Math.abs(num);

document.write("<h1>The absolute value of " + num + " is " + absVal + "</h1>");
