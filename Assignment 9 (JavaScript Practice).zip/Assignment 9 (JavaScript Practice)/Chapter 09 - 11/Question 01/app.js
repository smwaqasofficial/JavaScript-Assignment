// 1. Write a program to take “city” name as input from user. If user enters “Karachi”,
// welcome the user like this: “Welcome to city of lights”

var city = prompt("Enter your city name: ");

if (city === "Karachi" || city === "karachi" || city === "KARACHI") {
  document.write("Welcome to city of lights");
}
