// 3. Do the following using JS Mathematic Expressions
// a.Declare a variable.
// b.Show the value of variable in your browser like “Value after variable declaration is: ??”.
// c.Initialize the variable with some number.
// d.Show the value of variable in your browser like “Initial value: 5”.
// e.Increment the variable.
// f.Show the value of variable in your browser like “Value after increment is: 6”.
// g.Add 7 to the variable.
// h.Show the value of variable in your browser like “Value after addition is: 13”.
// i.Decrement the variable.
// j.Show the value of variable in your browser like “Value after decrement is: 12”.
// k.Show the remainder after dividing the variable’s value by 3.  l.Output : “The remainder is: 0”.

var num;

document.write("<h1>Value after variable declaration is: " + num + "<br></h1>");

num = 5;

document.write("<h1>Initial value: " + num + "<br></h1>");

num++;

document.write("<h1>Value after increment is: " + num + "<br></h1>");

num = num + 7;

document.write("<h1>Value after addition is: " + num + "<br></h1>");

num--;

document.write("<h1>Value after decrement is: " + num + "<br></h1>");

num = num % 3;

document.write("<h1>The remainder is: " + num + "<br></h1>");
