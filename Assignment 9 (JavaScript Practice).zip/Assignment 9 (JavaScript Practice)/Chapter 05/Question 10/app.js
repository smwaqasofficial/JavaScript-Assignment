﻿// 10. Write a program to initialize a variable with some number and do arithmetic in following sequence:
// a.Add 5
// b.Multiply by 10
// c.Divide the result by 2 Perform all calculations in a single expression

var num = 2;

var calculation = ((num + 5) * 10) / 2;

document.write("<h1>Initialize Value: " + num + "</h1>");

document.write("<h1>Result: " + calculation + "</h1>");
