// 5. Write a script to display multiplication table of any number in your browser.

var num = +prompt("Enter any number for table: ");
var count = 0;

document.write("<h2>Table of " + num + "</h2><br>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
document.write("<h2>" + num + " x " + ++count + " = " + num * count + "</h2>");
