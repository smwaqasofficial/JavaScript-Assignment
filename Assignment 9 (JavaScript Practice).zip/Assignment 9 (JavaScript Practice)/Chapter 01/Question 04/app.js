// 4. Write a script to display following messages in sequence:

alert("Welcome to JS land...");

alert("Happy Coding!");
