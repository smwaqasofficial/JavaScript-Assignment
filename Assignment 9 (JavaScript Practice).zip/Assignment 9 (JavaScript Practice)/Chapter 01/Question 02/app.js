// 2. Write a script to display following message on your web page:

alert("Error! Please enter a valid password.");
