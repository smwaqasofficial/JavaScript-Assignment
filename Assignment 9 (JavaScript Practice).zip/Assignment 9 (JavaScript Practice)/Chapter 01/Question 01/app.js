// 1. Write a script to greet your website visitor using JS alert box.

alert("Hi! Welcome to my Website");
