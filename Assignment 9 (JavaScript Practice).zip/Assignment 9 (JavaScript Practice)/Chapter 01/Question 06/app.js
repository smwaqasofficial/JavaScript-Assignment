// 6. Make use of alerts in your new /existing HTML & CSS project.

alert("Hi! Welcome to my Website!");
