// 3. Write a script to display following message on your web page: (Hint: Use line break)

alert("Welcome to JS land... \nHappy Coding!");
