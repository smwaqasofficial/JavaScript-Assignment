// 3. Write a program that takes input a name from user & greet the user.

var name = prompt("Enter your name: ");

document.write("<h1>Hi! " + name + " welcome to my website</h1>");
