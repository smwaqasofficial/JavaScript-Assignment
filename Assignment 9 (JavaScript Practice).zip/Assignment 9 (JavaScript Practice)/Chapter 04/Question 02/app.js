// 2. Declare 5 legal & 5 illegal variable names.

// Legal Variables

var legalVariable;

var _legalVariable;

var $leagalVariable;

var legalVariable_;

var legalVariable5;

// Illegal Variables

// var 1illegalVariable;
// var -illegalVariable;
// var if;
// var +illegalVariable;
// var !illegalVariable;
