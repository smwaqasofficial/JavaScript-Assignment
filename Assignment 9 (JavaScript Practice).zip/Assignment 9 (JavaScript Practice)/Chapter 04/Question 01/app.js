// 1. Declare 3 variables in one statement.

var firstOne, secondOne, thirdOne;
