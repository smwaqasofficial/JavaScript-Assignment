// 10. Write a program to print multiples of 5 ranging 1 to 100.

for (var i = 5; i <= 100; i += 5) {
  document.write(i + ", ");
}
