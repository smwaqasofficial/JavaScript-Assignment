// 1. Declare and initialize an empty multidimensional array. (Array of arrays)

var multiArray = [[], [], []];
