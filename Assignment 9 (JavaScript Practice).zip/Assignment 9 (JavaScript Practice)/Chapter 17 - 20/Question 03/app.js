// 3. Write a program to print numeric counting from 1 to 10.

for (var i = 1; i <= 10; i++) {
  document.write("<h1>" + i + "</h1>");
}
