// 2. Declare and initialize a multidimensional array representing the following matrix:

var multiArray = [
  [0, 1, 2, 3],
  [1, 0, 1, 2],
  [2, 1, 0, 1],
];

document.write(
  multiArray[0].join(" ") +
    "<br>" +
    multiArray[1].join(" ") +
    "<br>" +
    multiArray[2].join(" ")
);
