// 1. Show an alert box on click on a link.

function showAlert() {
  alert("Thanks for purchasing a phone from us");
}
