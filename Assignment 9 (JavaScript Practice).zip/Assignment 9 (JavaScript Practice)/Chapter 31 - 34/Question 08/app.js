// 8. Write a program that creates a Date object for the last day of the last month of 2020
// and assigns it to variable named laterDate.

var laterDate = new Date("Dec 31, 2020");

document.write("<h1>Later date: " + laterDate.toString() + "</h1>");
