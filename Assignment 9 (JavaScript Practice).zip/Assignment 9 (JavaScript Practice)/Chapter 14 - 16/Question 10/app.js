// 10. Write a program to store student scores in an array & sort the array in ascending order using Array’s sort method.

var studentScores = [320, 230, 480, 120];

document.write("Scores of Students : " + studentScores + "<br>");

document.write("Ordered Scores of Students : " + studentScores.sort());
