// 2. Declare an empty array using JS object notation to store student names in future.

var arr = {};
