// 5.  Declare and initialize a boolean array.

var arr = [true, false];
