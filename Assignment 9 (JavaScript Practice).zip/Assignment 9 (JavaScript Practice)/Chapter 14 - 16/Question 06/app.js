// 6. Declare and initialize a mixed array.

var arr = [true, "Cars", 5, "d"];
