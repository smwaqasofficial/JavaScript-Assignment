// Declare an empty array using JS literal notation to store student names in future.

var arr = {};
