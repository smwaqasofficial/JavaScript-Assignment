// 3. Declare and initialize a strings array.

var arr = ["zero", "one", "two"];
