// 4.  Declare and initialize a numbers array.

var arr = [1, 2, 3, 4];
