// 3. Write a function that adds two numbers(input by user) and returns the sum of two numbers.

function sum(numOne, numTwo) {
  var sum = numOne + numTwo;
  return sum;
}

alert(sum(2, 4));
