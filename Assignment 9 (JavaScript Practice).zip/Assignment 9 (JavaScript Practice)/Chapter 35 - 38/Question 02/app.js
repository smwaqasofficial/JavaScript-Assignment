// 2. Write a function that takes first & last name and then it greets the user using his full name.

function greet(firstName, lastName) {
  var fullName = firstName + " " + lastName;
  return "Hi! " + fullName + " Welcome to my website";
}

alert(greet("Moid", "Khan"));
