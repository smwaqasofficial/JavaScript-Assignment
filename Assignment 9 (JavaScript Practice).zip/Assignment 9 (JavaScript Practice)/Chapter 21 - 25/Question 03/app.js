// 3. Write a program to find the index of letter “n” in the word “Pakistani” and display the result in your browser.

var name = "Pakistani";
var indexOfN = name.indexOf("n");

document.write(
  "<h1>String: " + name + "<br>Index of 'n': " + indexOfN + "</h1>"
);
