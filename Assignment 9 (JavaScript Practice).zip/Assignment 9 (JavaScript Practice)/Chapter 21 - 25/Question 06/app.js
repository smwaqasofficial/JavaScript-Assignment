// 6. Repeat Q1 using string concat() method.

var str = "Q1";

var concatStr = str.concat(str);
document.write(
  "<h1>Orignal String: " +
    str +
    "<br>Repeated string using string concat() method: " +
    concatStr +
    "</h1>"
);
