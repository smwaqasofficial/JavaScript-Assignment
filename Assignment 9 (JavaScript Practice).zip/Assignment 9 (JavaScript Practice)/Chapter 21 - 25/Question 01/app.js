// 1. Write a program that takes two user inputs for first and last name using prompt and
// merge them in a new variable titled fullName.Greet the user using his full name.

var firstName = prompt("Enter your first name:");
var lastName = prompt("Enter your last name:");

var fullName = firstName + " " + lastName;

alert("Hi! " + fullName + ", Welcome to our website.");
