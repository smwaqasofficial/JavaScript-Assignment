// 4. Write a program to find the last index of letter “l” in the word “Hello World”
// and display the result in your browser

var name = "Hello World";
var lastIndexOfN = name.lastIndexOf("l");

document.write(
  "<h1>String: " + name + "<br>Last index of 'l': " + lastIndexOfN + "</h1>"
);
