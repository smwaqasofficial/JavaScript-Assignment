// 5. Write a program to find the character at 3rd index in the word “Pakistani” and display the result in your browser.

var name = "Pakistani";

var charAtThird = name.slice(3, 4);

document.write(
  "<h1>String: " + name + "<br>Character at index 3: " + charAtThird + "</h1>"
);
