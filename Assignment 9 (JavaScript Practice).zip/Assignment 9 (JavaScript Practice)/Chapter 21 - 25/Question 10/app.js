// 10. Write a program that takes user input.Convert and show the input in capital letters.

var input = prompt();

var capitalInput = input.toUpperCase();

document.write("User input: " + input + "<br>Upper case: " + capitalInput);
