// 9. Write a program that converts a string “472” to a number 472. Display the values & types in your browser.

var val = "472";
var convertedVal = Number(val);
document.write(
  "<h1>Value: " +
    val +
    "<br>Type: " +
    typeof val +
    "<br>Value: " +
    convertedVal +
    "<br>Type: " +
    typeof convertedVal +
    "<h1>"
);
