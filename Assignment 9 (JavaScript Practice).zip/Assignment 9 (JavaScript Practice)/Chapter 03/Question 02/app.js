// 2. Declare & initialize a variable to keep track of how many times a visitor has
// visited a web page.Show his / her number of visits on your web page.
// For example: “You have visited this site N times”.

var visitCount = 14;

alert("You have visited this site " + visitCount + " times");
