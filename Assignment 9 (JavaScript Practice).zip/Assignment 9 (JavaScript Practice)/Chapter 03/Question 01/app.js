// 1. Declare a variable called age & assign to it your age.Show your age in an alert box.

var age = 19;

alert("I am " + age + " years old");
