// 6. Declare a variable called email and assign to it a string that represents your Email Address(e.g.example@example.com)
//Show the blow mentioned message in an alert box.(Hint: use string concatenation)

var email = "example@example.com";

alert("My email address is " + email);
