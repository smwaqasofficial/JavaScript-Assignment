// 4. Write a script to save student’s bio data in JS variables and show the data in alert boxes.

var studentName = "Jhone Doe";
var studentAge = 15;
var studentCourse = "Certified Mobile Application Development";

alert(studentName);
alert(studentAge + " years old");
alert(studentCourse);
