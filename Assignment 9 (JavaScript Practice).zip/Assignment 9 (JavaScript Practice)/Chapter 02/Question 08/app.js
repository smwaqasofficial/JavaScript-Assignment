// 8. Write a script to display this in browser through JS

document.write("<h1>Yah! I can write HTML content through JavaScript</h1>");
