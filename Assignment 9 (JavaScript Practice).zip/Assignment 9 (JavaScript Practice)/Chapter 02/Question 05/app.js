// 5. Write a script to display the following alert using one JS variable:

var pizza = "PIZZA\nPIZZ\nPIZ\nPI\nP";

alert(pizza);
