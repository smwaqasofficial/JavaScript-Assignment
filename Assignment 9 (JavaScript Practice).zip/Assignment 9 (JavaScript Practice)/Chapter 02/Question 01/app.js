// 1. Declare a variable called username.

var username;
